# Explicación sencilla del dataset v6

## Para qué sirve

Entrena un buscador semántico: escribes lo ocurrido en español y el modelo ordena los artículos del Código Penal que podrían estar relacionados. El dataset le muestra ejemplos de esa relación. No convierte al modelo en un juez ni demuestra culpabilidad.

## De dónde salió

Partimos de 21.697 documentos del TSJ. Muchos son resoluciones sobre recursos y aspectos procesales. Descargar un documento no significa obtener un relato claro y una etiqueta correcta. Una resolución puede producir varios ejemplos o ninguno.

## Qué es un par y cuál es la etiqueta

Un par es una asociación entre un fragmento de hechos y un artículo candidato. `hechos` es el texto de entrada; `articulo` es la etiqueta; `articulo_texto` es el texto del artículo que debe recuperar el modelo.

Ejemplo inventado solo para explicar la estructura:

```json
{"hechos": "Una persona sustrajo un objeto y luego lo vendió...", "articulo": "NÚMERO_CANDIDATO", "articulo_texto": "Texto de ese artículo...", "estado_revision": "pendiente", "split": "train"}
```

Si el mismo fragmento tiene dos artículos asociados, hay dos pares. Por eso pares, textos distintos y resoluciones son cantidades diferentes.

## Cómo se obtuvieron las etiquetas

El extractor detecta citas explícitas al Código Penal y las relaciona con relatos próximos. Conserva la cita y su contexto para poder comprobar la asociación. Esto se llama supervisión débil. La cita puede ser de una acusación, condena, absolución o precedente. La extracción propone una etiqueta, pero no la aprueba jurídicamente.

En v6 se descartan propuestas nuevas con absolución, precedente o rol ambiguo. La variante ampliada puede incluir acusaciones, que siguen siendo acusaciones, no hechos judicialmente confirmados. Todos los pares actuales tienen estado pendiente.

## Qué cambió

- Se volvió a recorrer el corpus completo, comprobando que los archivos crudos coinciden con los usados en v4.
- Se buscan hasta 12 bloques por documento, frente a 4 antes.
- Una cita dentro del bloque se prioriza frente a citas externas más cercanas a sus bordes.
- Se conservan oraciones del documento, sin inventar relatos ni generar paráfrasis.
- Se exigen acciones concretas y se reducen fragmentos de teoría o trámite procesal.
- Palabras ambiguas como abuso o sujeto no cuentan automáticamente como acciones.
- Se comprueban relaciones con fuentes y textos de evaluación, incluyendo solapamiento léxico de ventanas recortadas.
- Se recuperaron 68 textos normativos ausentes desde una publicación oficial de la Fiscalía, conservando PDF, página y URL. No se certificó su vigencia para todas las fechas del corpus.

## Cantidades finales

| Versión | Pares totales | Train | Validation | Test | Entradas del catálogo |
|---|---:|---:|---:|---:|---:|
| v4 baseline | 300 | 259 | 18 | 23 | 376 |
| v5 experimental anterior | 321 | 280 | 18 | 23 | 376 |
| v6 conservador | 316 | 275 | 18 | 23 | 376 |
| v6 experimental ampliado | 368 | 327 | 18 | 23 | 444 |

La variante ampliada tiene 267 textos distintos en train y ejemplos para 68 artículos. El resto del catálogo puede recuperarse por el conocimiento del modelo base y el texto normativo, pero carece de ejemplos train específicos en esta versión.

Las variantes son alternativas: no se suman ni se deben mezclar sus archivos. Los 68 textos nuevos son documentos del catálogo, no 68 pares de casos nuevos. Las consultas y etiquetas de validation/test se conservaron exactamente. La ampliación del catálogo cambia el conjunto de candidatos que el modelo debe ordenar, así que afecta la dificultad de evaluación.

## Qué significa cada partición

Train enseña al modelo. Validation ayuda a elegir ajustes como tasa de aprendizaje y época. Test permite medir el resultado final y debe reservarse. Las 18 filas validation representan 16 consultas distintas; las 23 filas test representan 21 consultas distintas.

## Qué contiene cada archivo

| Archivo | Explicación sencilla |
|---|---|
| `pares_entrenamiento.jsonl` | Los ejemplos y su partición. Aunque el nombre diga entrenamiento, contiene también validation y test. |
| `pares_aumentados.jsonl` | Formato que consume el entrenador; actualmente contiene originales, sin paráfrasis nuevas. No sumarlo al archivo anterior. |
| `catalogo_cp.json` | Diccionario de números de artículo y sus textos. |
| `estadisticas_articulos.csv` | Cantidad de pares, resoluciones, textos distintos y ejemplos nuevos por artículo y partición. Se puede abrir en Excel. |
| `manifest.json` | Ficha de construcción: tamaño, particiones y huellas para identificar exactamente los archivos. |
| `auditoria_v6.json` | Conteos y controles de la mejora; no es un informe de accuracy o F1. |
| `nuevos_pares_pendientes.jsonl` | Los ejemplos nuevos seleccionados para esta versión. |
| `propuestas_secciones.jsonl` | Propuestas seleccionadas que puede procesar el aplicador de revisión de cada variante. |
| `cola_revision_prioritaria.jsonl` | Muestra priorizada de 68 propuestas para revisar, con atención a artículos escasos. |
| `plantilla_revisiones.jsonl` | Formulario estructurado con decisiones vacías. Debe completarlo una persona revisora. |
| `revision_muestra.html` | Vista legible de ejemplos, evidencia y enlaces del TSJ. |
| `catalogo_adiciones_fuente.jsonl` | Artículos nuevos con texto, página y procedencia. |
| `fuentes/` | PDF oficial y texto extraído por página para comprobar las adiciones. |
| `errores_extraccion.jsonl` | Fallos técnicos del extractor; esta corrida registró 0. Cero fallos no significa cero etiquetas incorrectas. |

JSON guarda una estructura completa. JSONL guarda un objeto por línea. CSV sirve para tablas simples. HTML sirve para leer la muestra en el navegador.

## Las columnas, agrupadas por propósito

| Grupo | Campos | Para qué sirven |
|---|---|---|
| Aprendizaje | hechos, articulo, articulo_texto, norma | Relacionan el relato con el documento normativo candidato. |
| Procedencia | fuente_id, fuente_url, nro_resolucion, nro_expediente, sala, fecha_emision, materia, tipo_proceso, resultado_resolucion | Permiten localizar y entender el documento de origen. Algunos campos no están disponibles en todas las filas. |
| Evidencia | cita_original, cita_inicio, cita_fin, evidencia_cita, papel_cita, distancia_cita | Explican por qué se propuso la etiqueta y dónde comprobarla. |
| Fragmento | hechos_original, hechos_inicio, hechos_fin, seccion, transformacion | Conservan el fragmento previo, su ubicación y los cambios extractivos realizados. |
| Filtros | tipo_contenido, señales_facticas, señales_procesales, senales_facticas, senales_procesales, acciones_pasado, prioridad | Describen reglas y conteos automáticos. No son probabilidades ni juicios jurídicos. Hay nombres con ñ heredados de v4 y sin ñ de v5. |
| Revisión | estado_revision, supervision, motivo, candidate_id, nivel_seleccion | Distinguen propuestas, su identidad y nivel conservador/ampliado. |
| Control | split, grupo_id, documento_hash, metodo, catalogo_origen | Mantienen particiones, trazabilidad y procedencia del texto normativo. |
| Aumento | tipo, parent_id | Identifican originales y posibles variantes. Actualmente todo sigue siendo original. |

Los offsets se miden en caracteres del documento limpiado, no en tokens ni en posiciones del PDF. Las huellas identifican contenido; no miden calidad. Una clave ausente o null significa que ese dato no está disponible.

## Qué se revisa antes de aprobar un par

Confirmar que el fragmento describe hechos del caso, que la cita pertenece al mismo caso, que el artículo está bien identificado y que su texto corresponde a la versión temporal adecuada. Si hay varios artículos válidos, deben registrarse todos los positivos conocidos. La persona revisora escribe aprobar/rechazar, artículos aprobados, su identificación y una justificación. El aplicador genera una nueva carpeta, retira propuestas rechazadas y sustituye etiquetas débiles revisadas sin modificar evaluación.

## Qué mejora está demostrada

Se amplió la extracción, se añadieron ejemplos pendientes con controles más explícitos y se completaron textos ausentes del catálogo. Los archivos fueron comprobados contra el lector E5 y la evaluación anterior. Pasaron 23 pruebas del código. No se entrenó el modelo en esta tarea, por lo que todavía no hay una mejora de F1 demostrada. La revisión jurídica y una comparación de entrenamiento siguen siendo necesarias para determinar el valor de los nuevos datos.
