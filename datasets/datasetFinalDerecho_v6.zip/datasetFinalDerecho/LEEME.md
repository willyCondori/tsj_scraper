# datasetFinalDerecho

La raíz contiene la variante v6 experimental ampliada: 368 pares (327 train, 18 validation, 23 test) y 444 entradas del catálogo. Todos los pares están pendientes de revisión jurídica. La carpeta comparacion_conservadora contiene 316 pares y el catálogo previo de 376 entradas, para comparar sin cambiar el conjunto de recuperación.

En Colab, usar /content/drive/MyDrive/datasetFinalDerecho como directorio del dataset ampliado. Para la comparación conservadora usar /content/drive/MyDrive/datasetFinalDerecho/comparacion_conservadora. No mezclar archivos de ambas variantes. Reutilizar split y reservar test.

Leer EXPLICACION_SENCILLA.md para entender ejemplos, etiquetas, archivos, columnas y límites. auditoria_v6.json verifica cantidades y conservación de las consultas/etiquetas de evaluación. La ampliación del catálogo cambia la dificultad de recuperación. Todavía no se entrenó el modelo con estos datos ni se demostró una mejora de F1.

La cola de revisión y su plantilla contienen 68 propuestas nuevas pendientes. Completar la plantilla y aplicar codigos/apply_reviews.py hacia una carpeta nueva. Una decisión rechazar elimina esa propuesta débil; aprobar sustituye sus etiquetas por las revisadas.

Los 68 textos normativos adicionales proceden de https://fiscalia.gob.bo/marco-legal/leyes/codigo-penal ; fuentes conserva el PDF y el texto por página, y catalogo_adiciones_fuente.jsonl documenta página y URL. La extracción no certifica la vigencia temporal de las normas.
